Dayspring Centre logo
A rising sun held by a welcoming shape represents hope, support and community.
Primary colour: deep teal #164E4A. Neutral: warm cream #FAF7F0.
SVG files scale without quality loss. PNG files have transparent backgrounds.
